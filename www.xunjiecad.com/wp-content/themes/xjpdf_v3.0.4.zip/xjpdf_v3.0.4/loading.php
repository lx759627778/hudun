<?php
/**
 * template name: loading
 */

?>
<style type="text/css">
    img{
        position: absolute;
        top: 40%;
        left:50%;
        margin-top: -21px;
        margin-left: -21px;
    }
</style>
<img src="<?php mySrc(); ?>/images/loading1.gif"/>