<section class="introduce buy-introduce-01">
    <div class="wrapper">
        <h2>产品介绍</h2>
        <p>迅捷PDF转换器是一款功能强大、界面简洁、操作简单的PDF转WORD软件，你只需把PDF文件拖拽到软件界面中，然后单击"转换"即可完成转换，经过不断地优化与升级，目前迅捷PDF转换器已经成功地实现了基于超线程技术的PDF文件批量转换技术，多个PDF文件实现批量一键转换，轻松快捷。</p>
    </div>
</section>
<section class="wrapper">
    <ul class="features-page-buy">
        <li>
            <div><em class="icon icon-buy-feature-1"></em>支持多种格式转换</div>
        </li>
        <li>
            <div><em class="icon icon-buy-feature-2"></em>转换快速质量保证</div>
        </li>
        <li>
            <div><em class="icon icon-buy-feature-3"></em>完美界面极佳体验</div>
        </li>
    </ul>
</section>