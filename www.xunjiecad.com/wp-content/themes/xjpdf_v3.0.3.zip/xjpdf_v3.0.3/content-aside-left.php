<aside class="guide-enter">
    <ul>
        <li><a href="<?php the_permalink(42);?>" class="a-01"><i></i><s>购买教程</s></a></li>
        <hr class="hr-x">
        <li><a href="<?php the_permalink(50);?>" class="a-02"><i></i><s>注册激活</s></a></li>
        <hr class="hr-x">
        <li><a href="<?php the_permalink(32);?>" class="a-03"><i></i><s>PDF转Word</s></a></li>
        <hr class="hr-x">
        <li><a href="<?php the_permalink(28);?>" class="a-04"><i></i><s>文件转Excel</s></a></li>
        <div class="clearfix"></div>
    </ul>
    <a class="drop"></a>
</aside>