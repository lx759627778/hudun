<div>
    <h1>联系方式</h1>
    <p><i><img src="<?php mySrc();?>/images/icon-001.png"></i><a href="<?php myQQLink();?>" target="_blank"><?php myQQNum();?></a></p><hr>
    <p><i><img src="<?php mySrc();?>/images/icon-002.png"></i><?php myPhoneNum();?></p><hr>
    <p><i><img src="<?php mySrc();?>/images/icon-003.png"></i>hudunpay</p><hr>
    <p><i><img src="<?php mySrc();?>/images/icon-004.png"></i>support@huduntech.com</p>
</div>