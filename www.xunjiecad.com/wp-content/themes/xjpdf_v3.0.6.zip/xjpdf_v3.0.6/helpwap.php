<?php
/**
 * Template Name:wap使用教程
 */
get_header();
?>
  <link rel="stylesheet" type="text/css" href="<?php mySrc(); ?>/wap/css/base.css">
  <link rel="stylesheet" type="text/css" href="<?php mySrc(); ?>/wap/css/index.css">
  <script src="<?php mySrc(); ?>/wap/js/common.js"></script>
  <script src="<?php mySrc(); ?>/wap/js/help.js"></script>
  <section class="help-ctt">
        <h6 class="help-h"></h6>
        <div class="help-step">
           
        </div>
    </section>
    <p class="js-url" style="display:none;"><?php mySrc(); ?></p>
<?php
get_footer();