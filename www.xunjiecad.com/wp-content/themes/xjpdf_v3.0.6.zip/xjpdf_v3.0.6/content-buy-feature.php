<div>
    <h1>软件特色</h1>
    <p><i><img src="<?php mySrc();?>/images/icon-005.png"></i>提高工作效率，减少重复劳动</p><hr>
    <p><i><img src="<?php mySrc();?>/images/icon-005.png"></i>转换效果更好，排版更精美</p><hr>
    <p><i><img src="<?php mySrc();?>/images/icon-005.png"></i>用户满意度高达99%</p><hr>
    <p><i><img src="<?php mySrc();?>/images/icon-005.png"></i>支持正版，支持国产</p>
</div>