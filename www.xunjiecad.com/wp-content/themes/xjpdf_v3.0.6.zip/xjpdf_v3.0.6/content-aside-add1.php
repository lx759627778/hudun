<div class="hero-aside-content">
    <a><img src="<?php mySrc();?>/images/logo-.png" alt="功能强大、界面简洁、操作简单的PDF转换成Word或者Word转换成PDF的软件"></a>
    <p>功能强大、界面简洁、操作简单的PDF转换成Word或者Word转换成PDF的软件</p>
    <a href="<?php myDownloadLink();?>" class="hero-download"><img src="<?php mySrc();?>/images/icon-hero-download.png" alt="">立即下载</a>
    <a href="<?php myDownloadLink();?>" class="aside-advertise"><img src="<?php mySrc();?>/images/aside-advertise-001.png" alt=""></a>
</div>