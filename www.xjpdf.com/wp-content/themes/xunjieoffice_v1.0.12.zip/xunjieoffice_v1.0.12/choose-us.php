<!-- 选择我们 -->
<section class="index-line">
    <div class="index-line-center  w1200">
        <h6>为什么选择我们</h6>
        <div class="index-line-ctt">
            <ul class="slt-my">
                <li>
                    <p class="icon-xz1">专属客服</p>
                </li>
                <li>
                    <p class="icon-xz2">免费升级</p>
                </li>
                <li>
                    <p class="icon-xz3">操作简单</p>
                </li>
                <li class="no-mr">
                    <p class="icon-xz4">绿色安全</p>
                </li>
            </ul>
        </div>
    </div>
</section>

