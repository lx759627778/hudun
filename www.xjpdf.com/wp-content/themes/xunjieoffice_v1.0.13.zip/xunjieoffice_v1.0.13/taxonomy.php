<?php
get_header();
get_template_part('template-part/content', 'page-our-products');
get_footer();