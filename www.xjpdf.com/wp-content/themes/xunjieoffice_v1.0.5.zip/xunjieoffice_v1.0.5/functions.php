<?php
require get_template_directory() . '/inc/function.php';
require get_template_directory() . '/inc/clean.php';
require get_template_directory() . '/inc/my-add.php';
require get_template_directory() . '/inc/my-contact.php';
require get_template_directory() . "/inc/my-meta-box.php";

