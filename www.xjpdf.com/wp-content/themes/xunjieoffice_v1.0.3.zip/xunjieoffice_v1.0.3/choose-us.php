<!-- 选择我们 -->
<section class="index-line">
    <div class="index-line-center  w1200">
        <h6>为什么选择我们</h6>
        <div class="index-line-ctt">
            <ul class="slt-my">
                <li>
                    <p class="icon-xz1">专属客服</p>
                </li>
                <li>
                    <p class="icon-xz2">专属客服</p>
                </li>
                <li>
                    <p class="icon-xz3">专属客服</p>
                </li>
                <li class="no-mr">
                    <p class="icon-xz4">专属客服</p>
                </li>
            </ul>
        </div>
    </div>
</section>

